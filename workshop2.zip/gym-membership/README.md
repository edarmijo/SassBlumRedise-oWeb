# Gym Membership Management System

Aplicación de línea de comandos para gestionar membresías de gimnasio: selección de plan,
características adicionales, cálculo de costos, descuentos grupales y ofertas especiales.

## Requisitos

- Python 3.10+
- pytest (solo para los tests)

```bash
pip install -r requirements.txt
```

## Cómo ejecutar

```bash
python main.py
```

## Cómo correr los tests

```bash
pytest -v
```

## Estructura del proyecto

```text
gym-membership/
├── main.py                 # Punto de entrada
├── gym_app/
│   ├── catalog.py          # Catálogo: planes, características, disponibilidad
│   ├── validation.py       # Validaciones de entrada y disponibilidad
│   ├── pricing.py          # Cálculo de costos, descuentos y recargos
│   └── cli.py              # Interacción con el usuario (menús, confirmación)
└── tests/
    ├── test_catalog.py
    ├── test_validation.py
    ├── test_pricing.py
    └── test_cli.py
```

## Reglas de negocio implementadas

| Regla | Detalle |
|---|---|
| Planes | Basic ($50), Premium ($120), Family ($180) |
| Características | Entrenamiento personal ($30), Clases grupales ($20), Plan nutricional ($25) |
| Características premium | Instalaciones exclusivas ($60), Programa especializado ($80) — recargo 15% |
| Descuento grupal | 2+ miembros en el mismo plan → 10% de descuento |
| Oferta especial | Total > $200 → −$20 · Total > $400 → −$50 (solo aplica la mayor) |
| Confirmación | El usuario revisa el resumen y confirma o cancela |
| Salida | Total como entero positivo si se confirma · `-1` si es inválido o se cancela |

## Supuestos (assumptions)

1. **Moneda y periodo:** todos los costos son USD mensuales y enteros.
2. **Orden de cálculo:** `(plan + características) × miembros` → recargo premium 15% →
   descuento grupal 10% → oferta especial. La oferta especial se evalúa sobre el total
   ya con recargo y descuento grupal aplicados.
3. **"Exceeds" es estrictamente mayor:** $200.00 exacto NO recibe descuento; $200.01 sí.
   Solo se aplica la oferta mayor (no son acumulables: > $400 aplica −$50, no −$70).
4. **Grupo:** todos los miembros del grupo comparten el mismo plan y las mismas
   características; se factura un solo total combinado.
5. **Recargo premium:** se aplica si la membresía incluye AL MENOS una característica
   premium, y recae sobre el total (plan + todas las características), no solo sobre
   la característica premium.
6. **Redondeo:** el total final se redondea al entero más cercano.
7. **Disponibilidad:** el catálogo incluye un plan (`student`) y una característica
   (`spa_access`) marcados como no disponibles para poder probar la regla 7 del enunciado.
8. **Cancelación o entrada inválida** en la confirmación final retorna `-1`.

## Reparto sugerido para el equipo

| Módulo | Responsable sugerido |
|---|---|
| `gym_app/catalog.py` + `tests/test_catalog.py` | Integrante 1 |
| `gym_app/validation.py` + `tests/test_validation.py` | Integrante 2 |
| `gym_app/pricing.py` + `tests/test_pricing.py` | Integrante 3 |
| `gym_app/cli.py` + `main.py` + `tests/test_cli.py` | Integrante 4 |
| README, supuestos y revisión final | Integrante 5 |
