# 🏆 Code Review Master — Skill de Auditoría de Software

> La skill de análisis de código más rigurosa que existe.
> Evalúa cualquier proyecto contra 7 estándares internacionales.

---

## ¿Qué hace?

Analiza el 100% de tu proyecto y lo evalúa contra:

| # | Estándar | Organización | Qué evalúa |
|---|----------|-------------|-----------|
| 1 | **ISO/IEC 25010** | ISO | Calidad del software |
| 2 | **OWASP Top 10 2025** | OWASP | Seguridad web |
| 3 | **WCAG 2.1 AA** | W3C | Accesibilidad |
| 4 | **SOLID + Clean Architecture** | Robert C. Martin | Arquitectura |
| 5 | **REST API Standards** | IETF (RFC 7231) | Diseño de APIs |
| 6 | **12-Factor App** | Heroku | Operabilidad |
| 7 | **CWE/SANS Top 25** | MITRE/SANS | Debilidades de código |

---

## Uso rápido

```bash
# 1. Recopilar código
bash ~/.openclaw/skills/code-review/scripts/collect_code.sh /ruta/a/tu/proyecto

# 2. Abrir tu LLM favorito
ollama run qwen3.5:27b
# o: ollama run glm-4.7-flash
# o: gemini en aistudio.google.com

# 3. Pegar el prompt de análisis
# (copia el contenido de ~/.openclaw/skills/code-review/prompts/analysis_prompt.md)

# 4. Pegar los 4 archivos generados:
#    - STATS.md
#    - CONFIG.md
#    - BACKEND.md
#    - FRONTEND.md

# 5. El LLM genera el reporte completo
```

---

## Output

El LLM genera un reporte con:

- **Puntuación /700** (100 por cada estándar)
- **Calificación A-F** (A = listo para producción)
- **Certificación** (APROBADO / CON CONDICIONES / RECHAZADO)
- **Hallazgos semi-formales** (con evidencia y código corregido)
- **Plan de corrección priorizado** (CRÍTICO → BAJO)
- **Análisis FODA**

---

## ¿Por qué es diferente?

| Otras skills | Esta skill |
|---|---|
| Analizan archivos seleccionados | **Analiza el 100% del código** |
| Sin estándares de referencia | **7 estándares internacionales** |
| "Hay un bug" | **"Viola OWASP A03, CWE-89, aquí está la línea, aquí la corrección"** |
| Sin puntuación medible | **Scoring /700 con calificación A-F** |
| Sin certificación | **¿Listo para producción? SÍ/NO/CON CONDICIONES** |

---

## Referencias

- ISO/IEC 25010:2023 → iso.org
- OWASP Top 10 2025 → owasp.org
- WCAG 2.1 → w3.org/TR/WCAG21/
- RFC 7231 → ietf.org
- 12-Factor App → 12factor.net
- CWE/SANS Top 25 → cwe.mitre.org/top25
- Clean Architecture → ISBN 978-0134494166
- Meta Semi-formal Reasoning → arxiv.org/abs/2603.01896
