#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# collect_code.sh — Recopila TODO el código de un proyecto
# Uso: bash collect_code.sh /ruta/al/proyecto
# ═══════════════════════════════════════════════════════════════

set -euo pipefail

PROJECT_ROOT="${1:-.}"
OUTPUT_DIR="$PROJECT_ROOT/.openclaw/tmp/code-review"
mkdir -p "$OUTPUT_DIR"

echo "📦 Recopilando código de: $PROJECT_ROOT"
echo ""

# ── Detectar stack tecnológico ──────────────────────────────────
detect_stack() {
    local stack=""
    [ -f "$PROJECT_ROOT/package.json" ] && stack="$stack Node/JS "
    [ -f "$PROJECT_ROOT/tsconfig.json" ] && stack="$stack TypeScript "
    [ -f "$PROJECT_ROOT/requirements.txt" ] || [ -f "$PROJECT_ROOT/Pipfile" ] || [ -f "$PROJECT_ROOT/pyproject.toml" ] && stack="$stack Python "
    [ -f "$PROJECT_ROOT/Cargo.toml" ] && stack="$stack Rust "
    [ -f "$PROJECT_ROOT/go.mod" ] && stack="$stack Go "
    [ -f "$PROJECT_ROOT/pom.xml" ] || [ -f "$PROJECT_ROOT/build.gradle" ] && stack="$stack Java "
    [ -f "$PROJECT_ROOT/Gemfile" ] && stack="$stack Ruby "
    [ -f "$PROJECT_ROOT/composer.json" ] && stack="$stack PHP "
    [ -f "$PROJECT_ROOT/pubspec.yaml" ] && stack="$stack Flutter/Dart "
    [ -f "$PROJECT_ROOT/docker-compose.yml" ] || [ -f "$PROJECT_ROOT/docker-compose.yaml" ] && stack="$stack Docker "
    [ -f "$PROJECT_ROOT/Jenkinsfile" ] && stack="$stack Jenkins "
    [ -d "$PROJECT_ROOT/.github/workflows" ] && stack="$stack GitHub-Actions "
    echo "${stack:-Unknown}"
}

# ── Detectar directorios principales ────────────────────────────
detect_dirs() {
    local backend_dirs=""
    local frontend_dirs=""
    
    # Backend patterns
    for d in backend server api app src/main src/api; do
        [ -d "$PROJECT_ROOT/$d" ] && backend_dirs="$backend_dirs $d"
    done
    
    # Frontend patterns
    for d in frontend client web src/components src/pages src/modules src/views; do
        [ -d "$PROJECT_ROOT/$d" ] && frontend_dirs="$frontend_dirs $d"
    done
    
    # Si no detecta separación clara, usar src/ como frontend
    if [ -z "$backend_dirs" ] && [ -z "$frontend_dirs" ]; then
        [ -d "$PROJECT_ROOT/src" ] && frontend_dirs=" src"
    fi
    
    echo "$backend_dirs|$frontend_dirs"
}

STACK=$(detect_stack)
DIRS=$(detect_dirs)
BACKEND_DIRS=$(echo "$DIRS" | cut -d'|' -f1)
FRONTEND_DIRS=$(echo "$DIRS" | cut -d'|' -f2)

# ── Extensiones a incluir ───────────────────────────────────────
BACKEND_EXTS="py|rb|go|java|rs|php|cs|swift|kt|scala|ex|exs|lua|pl|sh|sql"
FRONTEND_EXTS="tsx|ts|jsx|js|vue|svelte|css|scss|sass|less|html|astro"
CONFIG_EXTS="json|yaml|yml|toml|ini|cfg|conf|env|properties|xml"
DOC_EXTS="md|rst|txt"
BUILD_EXTS="Dockerfile|dockerfile|Makefile|makefile|Jenkinsfile|Vagrantfile"

# ── Excluir directorios ─────────────────────────────────────────
EXCLUDE_DIRS="node_modules|__pycache__|.git|dist|build|.next|.nuxt|vendor|venv|.venv|env|.tox|target|\.egg|\.cache|migrations|\.pytest_cache|\.mypy_cache|\.openclaw"

# ── STATS.md ────────────────────────────────────────────────────
echo "📊 Generando estadísticas..."
cat > "$OUTPUT_DIR/STATS.md" << EOF
# 📊 Estadísticas del Proyecto

**Fecha:** $(date -u +"%Y-%m-%d %H:%M UTC")
**Ruta:** $PROJECT_ROOT
**Stack detectado:** $STACK

## Archivos por tipo

EOF

# Contar por extensión
for ext in py tsx ts js jsx vue css scss html json yaml yml md sql go rs java rb; do
    count=$(find "$PROJECT_ROOT" -type f -name "*.$ext" \
        -not -path "*/.git/*" -not -path "*/node_modules/*" \
        -not -path "*/__pycache__/*" -not -path "*/migrations/*" \
        -not -path "*/dist/*" -not -path "*/build/*" \
        -not -path "*/.openclaw/*" \
        2>/dev/null | wc -l)
    [ "$count" -gt 0 ] && echo "- **.$ext:** $count archivos" >> "$OUTPUT_DIR/STATS.md"
done

# Total de archivos
total=$(find "$PROJECT_ROOT" -type f \
    -not -path "*/.git/*" -not -path "*/node_modules/*" \
    -not -path "*/__pycache__/*" -not -path "*/migrations/*" \
    -not -path "*/dist/*" -not -path "*/build/*" \
    -not -path "*/.openclaw/*" \
    2>/dev/null | wc -l)

# Total de líneas de código
total_lines=$(find "$PROJECT_ROOT" -type f \
    \( -name "*.py" -o -name "*.tsx" -o -name "*.ts" -o -name "*.js" -o -name "*.jsx" \
       -o -name "*.vue" -o -name "*.css" -o -name "*.scss" -o -name "*.html" \
       -o -name "*.go" -o -name "*.rs" -o -name "*.java" -o -name "*.rb" \) \
    -not -path "*/.git/*" -not -path "*/node_modules/*" \
    -not -path "*/__pycache__/*" -not -path "*/migrations/*" \
    -not -path "*/dist/*" -not -path "*/build/*" \
    -not -path "*/.openclaw/*" \
    -exec cat {} + 2>/dev/null | wc -l)

cat >> "$OUTPUT_DIR/STATS.md" << EOF

## Totales

- **Archivos totales:** $total
- **Líneas de código:** $total_lines
- **Directorios backend:** ${BACKEND_DIRS:-ninguno detectado}
- **Directorios frontend:** ${FRONTEND_DIRS:-ninguno detectado}

## Estructura de directorios (primer nivel)

\`\`\`
$(find "$PROJECT_ROOT" -maxdepth 2 -type d \
    -not -path "*/.git*" -not -path "*/node_modules*" \
    -not -path "*/__pycache__*" -not -path "*/.openclaw*" \
    -not -path "*/dist*" -not -path "*/build*" \
    | sort | head -60)
\`\`\`
EOF

echo "  ✅ STATS.md generado"

# ── Función para concatenar archivos ────────────────────────────
concat_files() {
    local output_file="$1"
    local title="$2"
    local dirs="$3"
    local extensions="$4"
    
    echo "# ═══════════════════════════════════════════════════════" > "$output_file"
    echo "# $title" >> "$output_file"
    echo "# Generado: $(date -u +"%Y-%m-%d %H:%M UTC")" >> "$output_file"
    echo "# ═══════════════════════════════════════════════════════" >> "$output_file"
    
    local file_count=0
    
    for dir in $dirs; do
        local full_dir="$PROJECT_ROOT/$dir"
        [ ! -d "$full_dir" ] && continue
        
        echo "" >> "$output_file"
        echo "---" >> "$output_file"
        echo "## 📁 $dir" >> "$output_file"
        echo "---" >> "$output_file"
        
        find "$full_dir" -type f \
            -not -path "*/__pycache__/*" \
            -not -path "*/migrations/*" \
            -not -path "*/node_modules/*" \
            -not -path "*/.openclaw/*" \
            2>/dev/null | sort | while IFS= read -r file; do
            # Saltar archivos en directorios excluidos
            echo "$file" | grep -qE "($EXCLUDE_DIRS)" && continue
            
            # Verificar que el archivo tiene una extensión válida
            local ext="${file##*.}"
            echo "$extensions" | grep -qw "$ext" || continue
            
            # Determinar lenguaje para el bloque de código
            local lang=""
            case "$ext" in
                py) lang="python" ;;
                ts|tsx) lang="typescript" ;;
                js|jsx) lang="javascript" ;;
                vue) lang="vue" ;;
                css|scss|sass|less) lang="css" ;;
                html) lang="html" ;;
                go) lang="go" ;;
                rs) lang="rust" ;;
                java) lang="java" ;;
                rb) lang="ruby" ;;
                php) lang="php" ;;
                sql) lang="sql" ;;
                sh) lang="bash" ;;
                json) lang="json" ;;
                yaml|yml) lang="yaml" ;;
                toml) lang="toml" ;;
                md) lang="markdown" ;;
                *) lang="" ;;
            esac
            
            local relative_path="${file#$PROJECT_ROOT/}"
            
            echo "" >> "$output_file"
            echo "### 📄 $relative_path" >> "$output_file"
            echo "\`\`\`$lang" >> "$output_file"
            cat "$file" >> "$output_file" 2>/dev/null || echo "# [Error leyendo archivo]" >> "$output_file"
            echo "" >> "$output_file"
            echo "\`\`\`" >> "$output_file"
            
            file_count=$((file_count + 1))
        done
    done
    
    echo "" >> "$output_file"
    echo "---" >> "$output_file"
    echo "**Total archivos incluidos:** $file_count" >> "$output_file"
    
    echo "  ✅ $(basename "$output_file") — $file_count archivos"
}

# ── BACKEND.md ──────────────────────────────────────────────────
echo "🔧 Recopilando backend..."
if [ -n "$BACKEND_DIRS" ]; then
    concat_files "$OUTPUT_DIR/BACKEND.md" "BACKEND COMPLETO" "$BACKEND_DIRS" "$BACKEND_EXTS"
else
    # Buscar archivos Python/Go/Rust/Java en todo el proyecto
    echo "  ⚠️ No se detectaron directorios backend claros. Buscando en todo el proyecto..."
    all_backend=""
    for d in $(find "$PROJECT_ROOT" -maxdepth 3 -type d \
        -not -path "*/.git/*" -not -path "*/node_modules/*" \
        -not -path "*/__pycache__/*" -not -path "*/.openclaw/*" \
        -not -path "*/dist/*" -not -path "*/build/*" \
        2>/dev/null); do
        if find "$d" -maxdepth 1 -type f -name "*.py" -o -name "*.go" -o -name "*.rs" -o -name "*.java" 2>/dev/null | head -1 | grep -q .; then
            all_backend="$all_backend ${d#$PROJECT_ROOT/}"
        fi
    done
    [ -n "$all_backend" ] && concat_files "$OUTPUT_DIR/BACKEND.md" "BACKEND COMPLETO" "$all_backend" "$BACKEND_EXTS"
    [ -z "$all_backend" ] && echo "# Sin código backend detectado" > "$OUTPUT_DIR/BACKEND.md"
fi

# ── FRONTEND.md ─────────────────────────────────────────────────
echo "🎨 Recopilando frontend..."
if [ -n "$FRONTEND_DIRS" ]; then
    concat_files "$OUTPUT_DIR/FRONTEND.md" "FRONTEND COMPLETO" "$FRONTEND_DIRS" "$FRONTEND_EXTS"
else
    echo "# Sin código frontend detectado" > "$OUTPUT_DIR/FRONTEND.md"
fi

# ── CONFIG.md ───────────────────────────────────────────────────
echo "⚙️ Recopilando configuración..."
cat > "$OUTPUT_DIR/CONFIG.md" << 'HEADER'
# ═══════════════════════════════════════════════════════
# CONFIGURACIÓN Y DOCUMENTACIÓN
# ═══════════════════════════════════════════════════════
HEADER

config_count=0

# Archivos de configuración en la raíz
for f in \
    "$PROJECT_ROOT"/*.md \
    "$PROJECT_ROOT"/package.json \
    "$PROJECT_ROOT"/tsconfig*.json \
    "$PROJECT_ROOT"/vite.config.* \
    "$PROJECT_ROOT"/webpack.config.* \
    "$PROJECT_ROOT"/next.config.* \
    "$PROJECT_ROOT"/tailwind.config.* \
    "$PROJECT_ROOT"/.env.example \
    "$PROJECT_ROOT"/.gitignore \
    "$PROJECT_ROOT"/.eslintrc* \
    "$PROJECT_ROOT"/.prettierrc* \
    "$PROJECT_ROOT"/Dockerfile* \
    "$PROJECT_ROOT"/docker-compose*.yml \
    "$PROJECT_ROOT"/docker-compose*.yaml \
    "$PROJECT_ROOT"/Jenkinsfile \
    "$PROJECT_ROOT"/Makefile \
    "$PROJECT_ROOT"/requirements*.txt \
    "$PROJECT_ROOT"/Pipfile \
    "$PROJECT_ROOT"/pyproject.toml \
    "$PROJECT_ROOT"/setup.py \
    "$PROJECT_ROOT"/setup.cfg \
    "$PROJECT_ROOT"/pytest.ini \
    "$PROJECT_ROOT"/tox.ini \
    "$PROJECT_ROOT"/go.mod \
    "$PROJECT_ROOT"/go.sum \
    "$PROJECT_ROOT"/Cargo.toml \
    "$PROJECT_ROOT"/Gemfile \
    "$PROJECT_ROOT"/composer.json \
    "$PROJECT_ROOT"/pubspec.yaml \
    "$PROJECT_ROOT"/angular.json \
    "$PROJECT_ROOT"/.babelrc \
    "$PROJECT_ROOT"/jest.config.* \
    "$PROJECT_ROOT"/vitest.config.* \
    "$PROJECT_ROOT"/cypress.config.* \
    "$PROJECT_ROOT"/playwright.config.*; do
    [ -f "$f" ] || continue
    relative="${f#$PROJECT_ROOT/}"
    echo "" >> "$OUTPUT_DIR/CONFIG.md"
    echo "### 📄 $relative" >> "$OUTPUT_DIR/CONFIG.md"
    echo '```' >> "$OUTPUT_DIR/CONFIG.md"
    cat "$f" >> "$OUTPUT_DIR/CONFIG.md" 2>/dev/null
    echo '```' >> "$OUTPUT_DIR/CONFIG.md"
    config_count=$((config_count + 1))
done

# Archivos .github/workflows
if [ -d "$PROJECT_ROOT/.github/workflows" ]; then
    for f in "$PROJECT_ROOT/.github/workflows"/*; do
        [ -f "$f" ] || continue
        relative="${f#$PROJECT_ROOT/}"
        echo "" >> "$OUTPUT_DIR/CONFIG.md"
        echo "### 📄 $relative" >> "$OUTPUT_DIR/CONFIG.md"
        echo '```yaml' >> "$OUTPUT_DIR/CONFIG.md"
        cat "$f" >> "$OUTPUT_DIR/CONFIG.md" 2>/dev/null
        echo '```' >> "$OUTPUT_DIR/CONFIG.md"
        config_count=$((config_count + 1))
    done
fi

echo "" >> "$OUTPUT_DIR/CONFIG.md"
echo "---" >> "$OUTPUT_DIR/CONFIG.md"
echo "**Total archivos de configuración:** $config_count" >> "$OUTPUT_DIR/CONFIG.md"

echo "  ✅ CONFIG.md — $config_count archivos"

# ── RESUMEN ─────────────────────────────────────────────────────
echo ""
echo "═══════════════════════════════════════════════════════"
echo "✅ Recopilación completa"
echo "═══════════════════════════════════════════════════════"
echo ""
echo "📁 Archivos generados en: $OUTPUT_DIR/"
echo ""
ls -lh "$OUTPUT_DIR/"
echo ""
echo "📊 Stack detectado: $STACK"
echo "📦 Archivos totales: $total"
echo "📝 Líneas de código: $total_lines"
echo ""
echo "Siguiente paso: Lee los 3 archivos (.md) y genera el análisis."
