# ═══════════════════════════════════════════════════════════════════════════════
# Code Review Master — Skill de Auditoría de Software de Clase Mundial
# ═══════════════════════════════════════════════════════════════════════════════
#
# Basado en estándares internacionales:
#   - ISO/IEC 25010:2023 — Modelo de calidad de software
#   - OWASP Top 10 2025 — Seguridad de aplicaciones web
#   - WCAG 2.1 AA (W3C) — Accesibilidad web
#   - RFC 7231/9110 — Diseño de APIs REST
#   - 12-Factor App (Heroku) — Operabilidad
#   - IEEE 1012-2016 — Verificación y validación de software
#   - CWE/SANS Top 25 2024 — Debilidades de software más peligrosas
#   - NIST SP 800-53 Rev. 5 — Controles de seguridad
#   - Google SRE — Confiabilidad de sitio
#   - Clean Architecture (Robert C. Martin) — Arquitectura de software
#   - SOLID Principles — Diseño orientado a objetos
#   - Meta Research arXiv:2603.01896 — Semi-formal Reasoning para LLMs
#
# PROPÓSITO: Evaluar cualquier proyecto contra estándares mínimos de una
# aplicación estable, segura, accesible y mantenible en producción.
# ═══════════════════════════════════════════════════════════════════════════════

# Code Review Master — Auditoría de Software con Estándares Internacionales

Auditoría completa de cualquier proyecto contra estándares mínimos de calidad,
seguridad, accesibilidad y operabilidad. Lee TODOS los archivos, evalúa contra
estándares reales, y produce un reporte priorizado con código corregido.

## Cuándo usar esta skill

- El usuario quiere una revisión completa de un proyecto
- El usuario pide "revisar", "auditar", "analizar", "code review"
- El usuario quiere saber si su proyecto está listo para producción
- El usuario quiere identificar brechas contra estándares de la industria

## Flujo de ejecución

### Paso 1: Recopilar TODO el código

```bash
bash SKILL_DIR/scripts/collect_code.sh RUTA_DEL_PROYECTO
```

Genera en `RUTA_DEL_PROYECTO/.openclaw/tmp/code-review/`:
- `STATS.md` — Estadísticas y stack detectado
- `CONFIG.md` — Configuración, docs, dependencias
- `BACKEND.md` — Todo el código backend
- `FRONTEND.md` — Todo el código frontend

### Paso 2: Leer los 4 archivos en orden

1. `STATS.md` → Alcance y tecnologías
2. `CONFIG.md` → Contexto y configuración
3. `BACKEND.md` → Código backend completo
4. `FRONTEND.md` → Código frontend completo

### Paso 3: Evaluar contra los 7 estándares

Usar `SKILL_DIR/prompts/analysis_prompt.md` como plantilla.
Evaluar contra estos 7 estándares obligatorios:

| # | Estándar | Qué evalúa | Referencia |
|---|----------|-----------|------------|
| 1 | **ISO/IEC 25010** | Calidad del software (8 características) | ISO 25010:2023 |
| 2 | **OWASP Top 10** | Seguridad de aplicaciones web | OWASP 2025 |
| 3 | **WCAG 2.1 AA** | Accesibilidad web | W3C |
| 4 | **SOLID + Clean Architecture** | Diseño y arquitectura | Robert C. Martin |
| 5 | **REST API Standards** | Diseño de APIs | RFC 7231/9110 |
| 6 | **12-Factor App** | Operabilidad | Heroku |
| 7 | **CWE/SANS Top 25** | Debilidades de código | CWE/SANS 2024 |

### Paso 4: Generar reporte

Escribir en `RUTA_DEL_PROYECTO/REPORTE_AUDITORIA.md` con:
1. Resumen ejecutivo con puntuación /700 (100 por cada estándar)
2. Evaluación detallada por cada estándar
3. Brechas identificadas con evidencia
4. Código corregido para cada brecha
5. Top 10 mejoras prioritarias
6. Plan de corrección priorizado con estimaciones
7. Certificación de aptitud para producción (SÍ/NO/CON CONDICIONES)

### Paso 5: Presentar resumen ejecutivo

Mostrar al usuario:
- Puntuación global /700 y calificación (A/B/C/D/F)
- Estado de cada estándar (✅ Cumple / ⚠️ Parcial / ❌ No cumple)
- ¿Está listo para producción? (SÍ / NO / CON CONDICIONES)
- Top 5 brechas críticas
- Tiempo estimado para alcanzar conformidad

## Puntuación por estándar (/100 cada uno)

Cada estándar se evalúa en 5 subcriterios de 20 puntos:

### 1. ISO/IEC 25010 — Calidad del Software
- Funcionalidad adecuada (/20)
- Fiabilidad (/20)
- Eficiencia de rendimiento (/20)
- Usabilidad (/20)
- Mantenibilidad (/20)

### 2. OWASP Top 10 2025 — Seguridad
- Control de acceso (/20)
- Criptografía y gestión de secretos (/20)
- Validación de entrada e inyección (/20)
- Configuración de seguridad (/20)
- Autenticación y sesión (/20)

### 3. WCAG 2.1 AA — Accesibilidad
- Perceptible (contraste, alt text, captions) (/20)
- Operable (teclado, focus, timing) (/20)
- Comprensible (lenguaje, predecible, input assistance) (/20)
- Robusto (parsing, compatibilidad, ARIA) (/20)
- Responsive y móvil (/20)

### 4. SOLID + Clean Architecture
- SRP — Responsabilidad única (/20)
- OCP + LSP — Abierto/cerrado y sustitución (/20)
- ISP + DIP — Segregación e inversión de dependencias (/20)
- Separación de capas (/20)
- Patrones de diseño (/20)

### 5. REST API Standards
- Métodos HTTP correctos (/20)
- Códigos de estado (/20)
- Versionado y negociación de contenido (/20)
- Paginación, filtrado, ordenamiento (/20)
- Documentación y contratos (/20)

### 6. 12-Factor App — Operabilidad
- Configuración en variables de entorno (/20)
- Dependencias declaradas y aisladas (/20)
- Backing services como recursos (/20)
- Procesos sin estado (/20)
- Disponibilidad y observabilidad (/20)

### 7. CWE/SANS Top 25 — Debilidades de Código
- Sin inyección (CWE-78, 79, 89) (/20)
- Sin broken access control (CWE-284, 287) (/20)
- Sin memory/safety issues (CWE-416, 787) (/20)
- Sin cryptographic failures (CWE-295, 321) (/20)
- Sin information exposure (CWE-200, 532) (/20)

## Calificación final

| Puntuación | Calificación | Significado |
|---|---|---|
| 630-700 | **A** | Excelente — Listo para producción |
| 560-629 | **B** | Bueno — Listo con mejoras menores |
| 490-559 | **C** | Aceptable — Necesita mejoras antes de producción |
| 420-489 | **D** | Deficiente — Requiere trabajo significativo |
| <420 | **F** | Inaceptable — No apto para producción |

## Reglas estrictas

1. **NO inventes problemas** — Cita archivo y línea exacta
2. **DA código corregido** — Para cada brecha, da la solución
3. **Sé exhaustivo** — Reporta TODAS las brechas encontradas
4. **Prioriza** — Por impacto en producción
5. **No pidas input** — Análisis autónomo
6. **Adapta al stack** — Los criterios se ajustan al tecnologías detectadas
7. **Sé honesto** — Si algo no se puede verificar, di "No verificable"

## Referencias

- ISO/IEC 25010:2023 — iso.org/standard/35733.html
- OWASP Top 10 2025 — owasp.org/www-project-top-ten
- WCAG 2.1 — w3.org/TR/WCAG21/
- RFC 7231 — tools.ietf.org/html/rfc7231
- 12-Factor App — 12factor.net
- CWE/SANS Top 25 — cwe.mitre.org/top25
- Clean Architecture — ISBN 978-0134494166
- Meta Semi-formal Reasoning — arxiv.org/abs/2603.01896
